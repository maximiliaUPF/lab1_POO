package Prac1;
import java.util.LinkedList;

public class DistanceMatrix {
    private LinkedList<GeometricPoint> cities;
    private double[][] matrix;

    public DistanceMatrix(){
        this.cities = new LinkedList<GeometricPoint>();
        
    }

    public void addCity(double x, double y, String name){
        GeometricPoint example = new GeometricPoint(x, y, name);
        cities.add(example);
        

    }

    public String getCityName(int index){
        String element = cities.get(index).getname();
        return element;

    }

    public double getNoOfCities(){
        return cities.size();
    }

    public double[][] createDistanceMatrix(LinkedList<GeometricPoint> cities){
        double[][] matrix = new double[cities.size()][2];
        for(int i = 0; i < cities.size(); i++){
            matrix[i][0] = cities.get(i).getx();
            matrix[i][1] = cities.get(i).gety();
        }
        return matrix;
    }

    public double getDistance(int index1, int index2, double[][] matrix){
        double firstd = matrix[index1][0] - matrix[index2][0];
        double second = matrix[index1][1] - matrix[index2][1];;
        firstd = Math.pow(firstd,2);
        second = Math.pow(second,2);
        double distance = Math.sqrt(firstd + second);
        
        return distance;
    }

}
