package Prac1;


public class GeometricPoint {
    private double x;
    private double y;
    private String name;
    
    public GeometricPoint(double x, double y){
        this.x = x;
        this.y = y;
    }

    public GeometricPoint(double x, double y, String name){
        this.x = x;
        this.y = y;
        this.name = name;
    }

    public double getx(){
        
        return this.x;

    }
    public double gety(){
        
        return this.y;

    }

    public String getname(){
        
        return this.name;

    }

    public void setx(double x){
        
        this.x=x;

    }
    public void sety(double y){
        
        this.y=y;

    }
    public double Distance(GeometricPoint p1){
        double firstd = this.x - p1.getx();
        double second = this.y - p1.gety();
        firstd = Math.pow(firstd,2);
        second = Math.pow(second,2);
        double distance = Math.sqrt(firstd + second);
        
        return distance;
    }

    public void PrintPoint(){
        String str1 = Double.toString(this.x);
        String str2 = Double.toString(this.y);
        String final_str = "The final point is: " + str1 + " " + str2;
        System.out.println(final_str);

    }

}

