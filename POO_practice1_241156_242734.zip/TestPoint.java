package Prac1;

//import jdk.javadoc.internal.doclets.formats.html.SourceToHTMLConverter;

public class TestPoint{
    public static void main(String[] args) throws Exception{
        GeometricPoint newpoint = new GeometricPoint(3, 4);
        GeometricPoint point2 = new GeometricPoint(2, 2);
        
        double finaldistance = newpoint.Distance(point2);

        System.out.println("The distance is: " + finaldistance);

        newpoint.PrintPoint();
    }


}