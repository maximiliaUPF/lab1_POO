package Prac1;

import java.util.LinkedList;

public class TestDistanceMatrix {

    public static void main(String[] args) throws Exception{
        LinkedList<GeometricPoint> cities = new LinkedList<GeometricPoint>();

        GeometricPoint city1 = new GeometricPoint(3, 4, "bcn");
        GeometricPoint city2 = new GeometricPoint(2, 2, "mad");
        GeometricPoint city3 = new GeometricPoint(3, 3, "val");
        GeometricPoint city4 = new GeometricPoint(5, 1, "alc");
        GeometricPoint city5 = new GeometricPoint(1, 5, "malg");

        cities.add(city1);
        cities.add(city2);
        cities.add(city3);
        cities.add(city4);
        cities.add(city5);
        DistanceMatrix distmatrix = new DistanceMatrix();
        double[][] matrix = new double[cities.size()][2];

        matrix = distmatrix.createDistanceMatrix(cities);
        
        double finaldistance = distmatrix.getDistance(1,2, matrix);
        System.out.println("The distance is: " + finaldistance);

        
}
}